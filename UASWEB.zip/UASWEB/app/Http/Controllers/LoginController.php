<?php

namespace App\Http\Controller;

class LoginController extends Controller

{
    public function index()
    {
        return view('login.index', [
            'title' => 'Login'
        ])  'active' => 'login'
    }
}